<template>
    <div>
        <h2>父组件接收到的参数：{{data}}</h2>
        <first-child @giveFather="receptionData"></first-child>
        <br/>
        <second-child></second-child>
        <br/>
        <thirdly-child :child-data="data"></thirdly-child>
    </div>
</template>
<script type="es6">
    import firstChild from './child/firstChild.vue';
    import secondChild from './child/secondChild.vue';
    import thirdlyChild from './child/thirdlyChild.vue';
    export default {
        data() {
            return {
                data:"",
            }
        },
        methods: {
            receptionData(value){
                this.data = value;
            }
        },
        components: {
            firstChild,
            secondChild,
            thirdlyChild,
        },
    }
</script>
