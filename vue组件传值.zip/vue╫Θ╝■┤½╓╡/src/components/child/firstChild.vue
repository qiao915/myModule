<template>
    <div style="border:1px solid red;">
        <h2>这是子组件1</h2>
        <input type="text" placeholder="请输入你要传的值"  v-model="data"/>
        <button @click="sendData1">传给父组件</button>
        <button @click="sendData2">传给兄弟组件</button>
        <h2></h2>
    </div>
</template>
<script type="es6">
    import bus from "../../assets/eventBus";
    export default {
        data() {
            return {
                data:"",
            }
        },
        methods: {
            sendData1(){
                this.$emit('giveFather',this.data);
            },
            sendData2(){
                bus.$emit('giveBrother',this.data);
            }
        },
    }
</script>
