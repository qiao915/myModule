<template>
  <div style="border:1px solid green;">
      <h2>这是子组件2</h2>
      <h3>收到的参数为：{{data}}</h3>
  </div>
</template>
<script type="es6">
    import bus from "../../assets/eventBus";
    export default {
        data() {
            return {
                data:'',
            }
        },
        mounted() {
            bus.$on('giveBrother',(item)=>{
              this.data = item;
          })
        },
    }
</script>
