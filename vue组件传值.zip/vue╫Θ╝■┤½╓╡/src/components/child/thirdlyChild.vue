<template>
    <div style="border:1px solid slateblue;">
        <h2>这是子组件3</h2>
        <h3>接收到父组件传的值：{{childData}}</h3>
    </div>
</template>
<script type="es6">
  export default {
      props: ['childData'],
      data() {
              return {
              }
          },
      }
</script>
