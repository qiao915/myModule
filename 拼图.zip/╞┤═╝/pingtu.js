(function($){
	var Puzzle = function(elem,options){
		this.specifications = options.specifications || [4,4];//定义几行几列
		this.smallImgWid = options.smallImgWid || 82; //定义分割图片的宽
		this.smallImgHight = options.smallImgHight || 82; //定义分割图片的高
		this.margin = options.margin || 2;//设置边距
		this.liArr = []; //保存li的坐标
		this.levelArr = []; //判断图是否拼完
		this.image = options.image || '';
	};
	Puzzle.prototype = {
		init : function(elem,options){
			var self = this;
			this.creatTags(elem);//创建元素
			$(elem).css({'position':'relative','touch-action':'none','width':'100%','overflow':'hidden'});
			$(elem).find('li').css({'float':'left'});
			this.initData(elem); //初始化值
			$.each($(elem).find('li'),function(){
				self.drag(elem,$(this),self.liArr,self.smallImgWid,options)
			});
		},	
		creatTags : function(elem){
			this.smallImgHight = this.smallImgWid = Math.floor(($(elem).width() - this.specifications[1]*this.margin)/this.specifications[1]);
			var tags = '' , 
				len = this.specifications[0]*this.specifications[1],// 图片分割总数
				indexArr = [] ,//索引数组
				smallImgWid = this.smallImgWid,
				smallImgHight = this.smallImgHight;
			
			for(var i = 0; i < len; i++) {
				indexArr.push(i);
				this.levelArr.push(i);
			}
			
			for(var i = 0; i < len; i++){
				var level = Math.floor(Math.random()*(indexArr.length-1));
				var index = indexArr[level];
				var position = (-Math.floor(index % this.specifications[1])*smallImgWid)+'px '+(-Math.floor(index / this.specifications[1])*smallImgWid)+'px';
				var style = 'background:url('+ this.image +') no-repeat '+position+'; background-size:'+ smallImgWid*this.specifications[1] +'px '+ smallImgWid*this.specifications[0] +'px; width:'+smallImgWid+'px; height:'+ smallImgHight+'px';
				
				tags += '<li index="'+ index +'" style="'+ style +'"></li>';
				indexArr.splice(level,1);
			}
			
			$(elem).html(tags);
		},
		
		initData : function(elem){ //elem : ul对象
			var offset = $(elem).offset(),
				smallImgWid = this.smallImgWid,
				uWidth = uHight = smallImgWid*this.specifications[0] + this.margin*(this.specifications[0] - 1) ; // ul宽高
			
			var liObj = $(elem).find('li');
			var self = this;
			
			$.each(liObj,function(){
				var liPosition = $(this).position();
				self.liArr.push([liPosition.left,liPosition.top]);
			});
		}, 
		
		result : function(elem,options){ //拖动后执行
			var levelStr = '';
			$.each($(elem).find('li'),function(i){
				levelStr += $(this).attr('index');
			});
			if(this.levelArr.join('') == levelStr) options.success(elem,options);
		},
		
		drag : function(elem,liElem,liArr,smallImgWid,options){ // elem:li对象, liArr:li的坐标 ,smallImgWid:li的宽度
			var initX = 0 , initY = 0 , //touchstart时的坐标
				endX = 0 , endY = 0 , //touchmove时的坐标
				offsetX = 0 , offsetY = 0 , //当前li的坐标
				subX = 0 , subY = 0 , //touchstart和li的差值
				uOffsetX = 0 , uOffsetY = 0; //ul的坐标
			var smallImgWid = smallImgHight = smallImgWid;
			var obj = this;	
			
			$(liElem).on('touchstart',function(e){ 
				var self = $(liElem);
				e.preventDefault();
				
				uOffsetX = $(elem).offset().left;
				uOffsetY = $(elem).offset().top;
				
				initX = e.originalEvent.touches[0].clientX - uOffsetX;
				initY = e.originalEvent.touches[0].clientY - uOffsetY;
				
				offsetX = $(this).position().left;
				offsetY = $(this).position().top;
				
				//差值
				subX = initX - offsetX ;
				subY = initY - offsetY; 
				
				var clone = $(this).clone(); 
				$(this).after(clone);
				
				$(clone).addClass('drag').css({'position':'absolute','left':($(this).position().left - 2) + 'px','top':($(this).position().top - 2) + 'px'});
				
				$(document).on('touchmove',function(ev){
					ev.preventDefault();
					endX = ev.originalEvent.touches[0].clientX - uOffsetX;
					endY = ev.originalEvent.touches[0].clientY - uOffsetY;
					
					$(clone).css({'left':(endX - subX) + 'px','top':(endY - subY) + 'px'});
				});
				
				$(document).on('touchend',function(ev){
					ev.preventDefault();
					$(clone).remove();
					$(this).off('touchmove');
					$(this).off('touchend');
					$.each(liArr,function(index){
						var vertex = Math.abs(Math.floor(liArr[index][0]) - (endX - subX)) <= Math.floor(smallImgWid/2)
										&& Math.abs(liArr[index][0] - (endX - subX)) <= Math.floor(smallImgWid/2)
										&& Math.abs(Math.floor(liArr[index][1]) - (endY - subY)) <= Math.floor(smallImgHight/2) 
										&& Math.abs(liArr[index][1] - (endY - subY)) <= Math.floor(smallImgHight/2);
						if(vertex){	
							var li = $('#puzzle').find('li');
							if(index - 1 == $(self).index()) {
								$(self).before($(li).eq(index));
							}else{
								$(self).after($(li).eq(index));
								(index - 1) >= 0 ? $(li).eq(index-1).after($(self)) : $(self).parent().prepend($(self));
							}
							obj.result(elem,options);
							return false;
						}
					});
				});
			});
		}
	};
	
	$.fn.puzzle = function(options){
		var options = $.extend({},$.fn.defaults,options);
		var pzl = new Puzzle(this,options);
		pzl.init(this,options);
	};
	
	$.fn.defaults = {
		success:function(elem,options){}	
	};
})(jQuery);